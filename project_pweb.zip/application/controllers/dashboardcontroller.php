	<?php if (!defined('BASEPATH')) {
	exit('No direct script access allowed');
}

class Dashboardcontroller extends CI_Controller {
	function __construct() {
		parent::__construct();
		if (empty($this->session->userdata('id'))) {
			redirect('login');
		}
	}

	public function dashboard() {
		$this->load->view('templates/header');
		$this->load->view('templates/sidebar');
		$this->load->view('dashboard');
		$this->load->view('templates/footer');
	}
}
