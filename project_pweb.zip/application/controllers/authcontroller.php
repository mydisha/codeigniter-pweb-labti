<?php if (!defined('BASEPATH')) {
	exit('No direct script access allowed');
}

class Authcontroller extends CI_Controller {
	function __construct() {
		parent::__construct();
		$this->load->model('auth');
		if (!empty($this->session->userdata('id'))) {
			redirect('dashboard');
		}
	}

	public function auth() {

		if ($_POST) {
			$auth = $this->auth->login($_POST);
			if (!empty($auth)) {
				$data = [
					'id' => $auth->id,
					'nama' => $auth->nama,
				];
				$this->session->set_userdata($data);
				redirect('dashboard');
			} else {
				$this->session->set_flashdata('error', 'Email / Password Salah');
				redirect('welcome');
			}
		}
		$this->load->view('welcome_message');
	}
}
