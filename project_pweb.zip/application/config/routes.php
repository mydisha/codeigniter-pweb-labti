<?php if (!defined('BASEPATH')) {
	exit('No direct script access allowed');
}

$route['default_controller'] = "welcome";
$route['404_override'] = '';

$route['auth'] = "authcontroller/auth";
$route['dashboard'] = "dashboardcontroller/dashboard";