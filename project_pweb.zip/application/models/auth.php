<?php if (!defined('BASEPATH')) {
	exit('No direct script access allowed');
}

class Auth extends CI_Model {
	public $table = "tbl_User";

	public function login($data) {
		$this->db->where('email', $data['email']);
		$this->db->where('password', md5($data['password']));
		return $this->db->get($this->table)->row();
	}
}
